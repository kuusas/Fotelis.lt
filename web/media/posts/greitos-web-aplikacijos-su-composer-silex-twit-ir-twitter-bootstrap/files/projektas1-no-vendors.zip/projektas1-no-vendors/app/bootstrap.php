<?php
require_once __DIR__.'/../vendor/autoload.php'; 

// Init Application
$app = new Silex\Application(); 
$app['debug'] = true;

// services
$app->register(new Silex\Provider\TwigServiceProvider(), array(
    'twig.path' => __DIR__.'/views',
));

// Define routes
$app->get('/', function() use($app) { 
    return $app['twig']->render('index.html.twig');
}); 

$app->get('/labas/{name}', function($name) use($app) { 
    return $app['twig']->render('labas.html.twig', array(
        'name' => $name
    ));
}); 



// Run Application
$app->run(); 